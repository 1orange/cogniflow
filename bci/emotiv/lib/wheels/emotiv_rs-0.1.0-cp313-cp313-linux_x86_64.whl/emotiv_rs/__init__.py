from .emotiv_rs import *

__doc__ = emotiv_rs.__doc__
if hasattr(emotiv_rs, "__all__"):
    __all__ = emotiv_rs.__all__